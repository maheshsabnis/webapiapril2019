﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
namespace WebApiApp.Models
{
    public class Category
    {
        [Key] // Primary Identity Key
        public int CategoryRowId { get; set; }
        [Required(ErrorMessage ="Category Id is Required")]
        public string CategoryId { get; set; }
        [Required(ErrorMessage = "Category Name is Required")]
        public string CategoryName { get; set; }
        [Required(ErrorMessage = "Base Price is Required")]
        [NumericNonNegative(ErrorMessage ="Base Price Cannot be -Ve")]
        public int BasePrice { get; set; }
    }

    public class Product
    {
        [Key]
        public int ProductRowId { get; set; }
        [Required(ErrorMessage ="Product Id is required")]
        public string ProductId { get; set; }
        [Required(ErrorMessage = "Product Name is required")]
        public string ProductName { get; set; }
        [Required(ErrorMessage = "Product Price is required")]
        public int Price { get; set; }
        [Required(ErrorMessage = "Category Row Id is required")]
        public int CategoryRowId { get; set; }
        public Category Category { get; set; }
    }


    public class NumericNonNegativeAttribute : ValidationAttribute
    {
        public override bool IsValid(object value)
        {
            if (Convert.ToInt32(value) < 0) return false;
            return true;
        }
    }

     
}