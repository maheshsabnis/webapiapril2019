﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using WebApiApp.Models;
using WebApiApp.Repositories;
using System.Web.Http.Description;
namespace WebApiApp.Controllers
{
    public class ProductAPIController : ApiController
    {
        // defin the repository reference for Category
        IRepository<Product, int> prdRepository;
        IRepository<Category, int> catRepository;
        /// <summary>
        /// Inject the CategoryRepositoiry in ctor
        /// </summary>
        public ProductAPIController(IRepository<Product, int> prdRepository, IRepository<Category, int> catRepository)
        {
            this.prdRepository = prdRepository;
            this.catRepository = catRepository;
        }

        [ResponseType(typeof(List<Product>))]
        public IHttpActionResult Get()
        {
            var prds = prdRepository.Get();
            return Ok(prds);
        }

        [ResponseType(typeof(Product))]
        public IHttpActionResult Get(int id)
        {
            var prd = prdRepository.Get(id);
            return Ok(prd);
        }

        [ResponseType(typeof(Product))]
        public IHttpActionResult Post(Product product)
        {
            if (ModelState.IsValid)
            {
                var cat = catRepository.Get(product.CategoryRowId);
                if (cat.BasePrice > product.Price)
                {
                    return BadRequest($"The Product Price {product.Price} for the category {cat.CategoryName} " +
                        $"is less than the base price {cat.BasePrice}");
                }

                product = prdRepository.Create(product);
                return Ok(product);
            }
            else
            {
                return BadRequest(ModelState);
            }
            
        }

        [ResponseType(typeof(bool))]
        public IHttpActionResult Put(int id, Product product)
        {
            bool res = prdRepository.Update(id, product);
            return Ok(res);
        }

        [ResponseType(typeof(bool))]
        public IHttpActionResult Delete(int id)
        {
            bool res = prdRepository.Delete(id);
            return Ok(res);
        }

    }
}
