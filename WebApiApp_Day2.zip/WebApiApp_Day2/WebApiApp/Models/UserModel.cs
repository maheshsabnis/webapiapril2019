﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApiApp.Models
{
    public class UserModel
    {
        public string UserName { get; set; }
        public string Password { get; set; }
    }

    public class UsersDb : List<UserModel>
    {
        public UsersDb()
        {
            Add(new UserModel() { UserName = "mahesh", Password = "msit" });
            Add(new UserModel() { UserName = "tejas", Password = "msit" });
        }
    }

    public class AuthUser
    {
        UsersDb users = new UsersDb();
        bool ChekcUserExists(string username)
        {
            var user = users.Where(u=>u.UserName==username.Trim()).FirstOrDefault();
            if (user == null) return false;
            return true;
        }

        public bool IsAuthenticated(UserModel user)
        {
            if (ChekcUserExists(user.UserName))
            {
                foreach (var u in users)
                {
                    if (u.Password.Trim() == user.Password.Trim())
                    {
                        return true;
                    }
                }
            }
            return false;
        }
    }
}