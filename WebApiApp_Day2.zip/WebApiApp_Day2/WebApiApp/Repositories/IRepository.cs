﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebApiApp.Repositories
{
    /// <summary>
    /// The interface that will contain methods (operations) for CRUD
    /// using Entity Classes 
    /// </summary>
    /// <typeparam name="TEntity">Will always be entity class e.g. Category/Product</typeparam>
    /// <typeparam name="TPk">Will always be an input parameter to method for Get with id, Update and Delete Operations</typeparam>
    public interface IRepository<TEntity, in TPk> where TEntity:class
    {
        IEnumerable<TEntity> Get();
        TEntity Get(TPk id);
        TEntity Create(TEntity entity);
        bool Update(TPk id, TEntity entity);
        bool Delete(TPk id);
    }
}
