﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using WebApiApp.Models;
using WebApiApp.Repositories;

namespace WebApiApp.Controllers
{
    public class SearchAPIController : ApiController
    {
        IRepository<Category, int> rc;
        IRepository<Product, int> rp;

        public SearchAPIController(IRepository<Category, int> rc, IRepository<Product, int> rp)
        {
            this.rc = rc;
            this.rp = rp;
        }

        [HttpGet]
        [Route("api/search/{catname}/{condition}/{prdname}")]
        [ResponseType(typeof(List<Product>))]
        public IHttpActionResult Search(string catname, string condition, string prdname)
        {
            List<Product> products = new List<Product>();
            var cat = (from c in rc.Get().ToList()
                       where c.CategoryName == catname.Trim()
                       select c).FirstOrDefault();
            switch (condition)
            {
                case "OR":
                    products = (from p in rp.Get().ToList()
                                where p.ProductName == prdname.Trim() || p.CategoryRowId == cat.CategoryRowId
                                select p).ToList();
                    break;
                case "AND":
                    products = (from p in rp.Get().ToList()
                                where p.ProductName == prdname.Trim() && p.CategoryRowId == cat.CategoryRowId
                                select p).ToList();
                    break;
            }
            return Ok(products);
        }
    }
}
