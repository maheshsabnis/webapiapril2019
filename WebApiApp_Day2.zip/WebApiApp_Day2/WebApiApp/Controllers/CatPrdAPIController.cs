﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using WebApiApp.Models;
using WebApiApp.Repositories;

namespace WebApiApp.Controllers
{
    public class CatPrdAPIController : ApiController
    {
        IRepository<Category, int> catReposigtory;
        IRepository<Product, int> prdrepository;


        public CatPrdAPIController(IRepository<Category, int> catReposigtory, IRepository<Product, int> prdrepository)
        {
            this.catReposigtory = catReposigtory;
            this.prdrepository = prdrepository;
        }


        //[ResponseType(typeof(Product))]
        //public IHttpActionResult Post([FromUri]Category category,[FromBody]Product product)
        //{
        //    catReposigtory.Create(category);
        //    prdrepository.Create(product);
        //    return Ok(product);
        //}

        [ResponseType(typeof(Product))]
        public IHttpActionResult Post(ApiViewModel viewModel)
        {
            catReposigtory.Create(viewModel.Category);
            prdrepository.Create(viewModel.Product);
            return Ok(viewModel);
        }
    }
}
