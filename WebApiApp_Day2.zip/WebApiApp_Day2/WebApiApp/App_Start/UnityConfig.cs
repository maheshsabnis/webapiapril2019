using System.Web.Http;
using Unity;
using Unity.WebApi;
using WebApiApp.Models;
using WebApiApp.Repositories;

namespace WebApiApp
{
    public static class UnityConfig
    {
        public static void RegisterComponents()
        {
			var container = new UnityContainer();

            // register all your components with the container here
            // it is NOT necessary to register your controllers
            // registering AppDbContext aka DAL 
            container.RegisterType<ApplicationDbContext>();
            container.RegisterType<ApplicationUser>();
            container.RegisterType<ApplicationUserManager>();
            container.RegisterType<AppDbContext>();
            container.RegisterType<IRepository<Category, int>, CategoryRepository>();
            container.RegisterType<IRepository<Product, int>, ProductRepository>();

            GlobalConfiguration.Configuration.DependencyResolver = new UnityDependencyResolver(container);
        }
    }
}