﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http.Controllers;
using System.Web.Http.Filters;
using WebApiApp.Models;

namespace WebApiApp.CustomFilters
{
    public class CustomAuthFilterAttribute : AuthorizationFilterAttribute
    {
        public override void OnAuthorization(HttpActionContext actionContext)
        {
            var authHeader = actionContext.Request.Headers.Authorization;
            if (authHeader.Scheme == "Basic" || authHeader.Scheme == "basic")
            {
                var credentials = authHeader.Parameter.Split(':');
                var userModel = new UserModel();
                var authUser = new AuthUser();
                userModel.UserName = credentials[0];
                userModel.Password = credentials[1];

                if (authUser.IsAuthenticated(userModel))
                {
                    base.OnAuthorization(actionContext);
                    return;
                }
                else
                {
                    actionContext.Response = new System.Net.Http.HttpResponseMessage(System.Net.HttpStatusCode.Unauthorized);
                }
            }
            else
            {
                actionContext.Response = new System.Net.Http.HttpResponseMessage(System.Net.HttpStatusCode.Unauthorized);
            }
        }
    }
}